MINI ROYALE 4.18 — PROJETO ANDROID

Este pacote contém um projeto Android Studio que abre o HTML do MINI ROYALE
em uma WebView, em tela cheia e com orientação horizontal.

IMPORTANTE:
- Este pacote é o projeto-fonte Android, não um APK já compilado.
- O ambiente usado para preparar este pacote não possui Android SDK/Gradle,
  então não foi possível compilar nem testar um APK aqui.
- O HTML atual carrega Three.js pelo CDNJS. Portanto, a primeira inicialização
  e os recursos que dependem desse CDN precisam de conexão com a internet.
- O desempenho real varia conforme o aparelho Android.

COMO GERAR O APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta MINI_ROYALE_ANDROID.
3. Aguarde o Gradle sincronizar e baixar as dependências.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O Android Studio exibirá o caminho do APK gerado.
6. Envie o APK aos seus amigos para instalação.

O app está configurado para:
- Nome: MINI ROYALE
- Versão: 4.18
- Orientação: paisagem (horizontal)
- Tela cheia
- JavaScript e armazenamento local habilitados
